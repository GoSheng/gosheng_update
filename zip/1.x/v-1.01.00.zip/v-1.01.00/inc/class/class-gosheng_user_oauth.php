<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'GoSheng_user_oauth' ) ) {
	class GoSheng_user_oauth {

	}
}