<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
Bootstrap archive
<?php get_footer(); ?>
