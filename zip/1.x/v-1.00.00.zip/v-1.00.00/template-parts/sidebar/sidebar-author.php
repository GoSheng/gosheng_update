<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="p-2 mb-3">
    author侧边栏文件sidebar
</div>