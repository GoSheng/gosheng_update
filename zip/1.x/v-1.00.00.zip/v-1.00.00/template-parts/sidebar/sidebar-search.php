<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="p-2 mb-3">
    search侧边栏文件sidebar
</div>