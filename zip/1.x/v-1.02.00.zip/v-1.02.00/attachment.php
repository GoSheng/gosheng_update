<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
Bootstrap attachment
<?php get_footer(); ?>
