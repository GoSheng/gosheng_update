<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header(); ?>
Bootstrap author
<?php get_footer(); ?>
