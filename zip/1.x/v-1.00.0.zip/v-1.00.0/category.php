<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<?php get_header(); ?>
<?php get_template_part( 'template-parts/category/category', 'default' ); ?>
<?php get_footer(); ?>
