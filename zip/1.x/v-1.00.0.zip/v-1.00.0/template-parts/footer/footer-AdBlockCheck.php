<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div id="AdBlockCheck" class="container-fluid AdBlockCheckBanner invisible">
    <div class="container AdblockBanner-inner"></div>
</div>