<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div id="gosheng_follow_bar" class="p-absolute" style="min-height:500vh;">
    <div class="theiaStickySidebar">
        <span>跟随栏</span>
    </div>
</div>
