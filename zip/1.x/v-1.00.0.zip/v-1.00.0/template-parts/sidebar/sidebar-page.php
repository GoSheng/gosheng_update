<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="p-2 mb-3">
    page侧边栏文件sidebar
</div>