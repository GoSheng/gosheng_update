<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header(); ?>
<?php get_search_form(); ?>
<?php get_footer(); ?>
