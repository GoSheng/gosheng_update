<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();

get_template_part( 'searchform' );

get_footer();
?>
